import Image from "next/image"

export default function About() {
  return (
    <main className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-8">About MinaMetrics</h1>

        <div className="space-y-8 text-muted-foreground">
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">Our Mission</h2>
            <p className="leading-relaxed">
              We are dedicated to providing professional surveying and mapping services that support successful project
              delivery. Our mission is to deliver accurate, reliable data and innovative solutions for engineering,
              construction, and land development projects.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">Experience & Expertise</h2>
            <p className="leading-relaxed">
              With years of experience in geodesy, topography, and surveying, our team brings expertise and precision to
              every project. We utilize state-of-the-art surveying equipment and modern data processing techniques to
              ensure accuracy and efficiency.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">Our Equipment</h2>
            <p className="leading-relaxed">
              We employ advanced surveying instruments including total stations, GNSS receivers, and laser scanning
              technology to capture precise spatial data for diverse project requirements.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-foreground mb-4">Quality Assurance</h2>
            <p className="leading-relaxed">
              Every project follows rigorous quality control procedures to ensure data accuracy and compliance with
              industry standards. We are committed to delivering exceptional results that exceed client expectations.
            </p>
          </section>

          <section className="border-t border-border pt-8 mt-8">
            <h2 className="text-2xl font-bold text-foreground mb-6">Founder & CEO</h2>
            <div className="flex flex-col sm:flex-row gap-8 items-start">
              {/* CEO Photo */}
              <div className="flex-shrink-0 w-full sm:w-64">
                <div className="relative w-64 h-80 rounded-lg overflow-hidden bg-gray-200 border-2 border-primary/20">
                  <Image
                    src="/images/20250815-141258-0000.png"
                    alt="Tika Nur Aminah - CEO MinaMetrics"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>

              {/* CEO Info */}
              <div className="flex-1">
                <h3 className="text-xl font-bold text-foreground mb-2">Tika Nur Aminah</h3>
                <p className="text-primary font-semibold mb-4">Founder & Chief Executive Officer</p>

                <div className="space-y-3 text-muted-foreground">
                  <p>
                    <strong className="text-foreground">Education:</strong>
                    <br />
                    Universitas Wijaya Kusuma Purwokerto
                  </p>
                  <p>
                    Tika Nur Aminah is an accomplished surveying professional with extensive knowledge in geodesy,
                    topography, and surveying technology. Under her leadership, MinaMetrics has become a trusted partner
                    for precision surveying and mapping services.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </main>
  )
}
