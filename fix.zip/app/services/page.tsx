export default function Services() {
  const serviceDetails = [
    {
      title: "Topographic Survey",
      description: "Comprehensive terrain mapping with elevation data",
      features: ["Elevation contours", "Terrain analysis", "Digital elevation models", "Site documentation"],
    },
    {
      title: "Control Point Establishment",
      description: "Precision polygon and control point setup",
      features: ["Horizontal control", "Vertical control", "Reference frame setup", "Point validation"],
    },
    {
      title: "Contour & Visualization",
      description: "Professional contour generation and mapping",
      features: ["Customizable intervals", "2D visualization", "3D terrain modeling", "Interactive tools"],
    },
    {
      title: "Situation Mapping",
      description: "Comprehensive site and infrastructure mapping",
      features: ["Boundary mapping", "Infrastructure documentation", "Land use mapping", "Site planning"],
    },
    {
      title: "GIS Services",
      description: "Geographic information system solutions",
      features: ["Spatial analysis", "Data integration", "Map production", "Database management"],
    },
    {
      title: "Data Processing",
      description: "Advanced survey data processing and analysis",
      features: ["Data validation", "Coordinate transformation", "Quality assurance", "Report generation"],
    },
  ]

  return (
    <main className="min-h-screen bg-background">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-4">Our Services</h1>
        <p className="text-lg text-muted-foreground mb-12 max-w-2xl">
          Comprehensive surveying and mapping solutions for diverse project requirements
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {serviceDetails.map((service, index) => (
            <div key={index} className="bg-card rounded-lg border border-border p-8 hover:shadow-lg transition-shadow">
              <h3 className="text-xl font-bold text-foreground mb-2">{service.title}</h3>
              <p className="text-muted-foreground mb-4">{service.description}</p>
              <ul className="space-y-2">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                    <span className="text-primary font-bold">•</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
