"use client"

import { useState, useRef } from "react"
import CalculatorForm from "@/components/calculator/form"
import CalculatorResults from "@/components/calculator/results"
import Visualization2D from "@/components/calculator/visualization-2d"
import Visualization3D from "@/components/calculator/visualization-3d"
import LayerControl from "@/components/calculator/layer-control"

export default function Calculator() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [polygonPoints, setPolygonPoints] = useState([
    { name: "A", x: 0, y: 0, z: 100 },
    { name: "B", x: 200, y: 50, z: 105 },
    { name: "C", x: 150, y: 200, z: 110 },
  ])

  const [detailPoints, setDetailPoints] = useState([
    { name: "a1", origin: "A", azimuth: 30, distance: 80, elevation: 102, x: 69.28, y: 40, z: 102 },
    { name: "b1", origin: "A", azimuth: 60, distance: 120, elevation: 104, x: 60, y: 103.92, z: 104 },
    { name: "c1", origin: "A", azimuth: 90, distance: 150, elevation: 106, x: 150, y: 0, z: 106 },
    { name: "a2", origin: "B", azimuth: 120, distance: 100, elevation: 108, x: 250, y: -16.45, z: 108 },
    { name: "b2", origin: "B", azimuth: 180, distance: 80, elevation: 107, x: 200, y: -30, z: 107 },
    { name: "c2", origin: "C", azimuth: 225, distance: 90, elevation: 109, x: 86.36, y: 136.36, z: 109 },
    { name: "a3", origin: "C", azimuth: 270, distance: 70, elevation: 111, x: 80, y: 200, z: 111 },
    { name: "b3", origin: "A", azimuth: 135, distance: 110, elevation: 103, x: 77.78, y: 77.78, z: 103 },
    { name: "c3", origin: "B", azimuth: 45, distance: 85, elevation: 105, x: 260.1, y: 110.1, z: 105 },
    { name: "a4", origin: "C", azimuth: 315, distance: 95, elevation: 112, x: 217.17, y: 132.17, z: 112 },
  ])

  const [contourInterval, setContourInterval] = useState(2)
  const [gridResolution, setGridResolution] = useState(15)
  const [show3D, setShow3D] = useState(false)
  const [layers, setLayers] = useState({
    polygonPoints: true,
    detailPoints: true,
    interpolationPoints: true,
    labels: true,
    polygonLines: true,
    detailLines: true,
    contours: true,
    networkEdges: false, // Hidden by default untuk reduce clutter
  })

  return (
    <main className="min-h-screen bg-background py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-2">Survey Calculator</h1>
          <p className="text-lg text-muted-foreground">
            Interactive tool for computing survey coordinates and visualizing terrain contours
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form Section */}
          <div className="lg:col-span-1">
            <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
              <p className="text-xs text-green-800">
                <strong>Data default sudah dimuat!</strong> Anda bisa langsung melihat visualisasi di kanan, atau
                tambahkan detail point baru menggunakan form di bawah.
              </p>
            </div>
            <CalculatorForm
              polygonPoints={polygonPoints}
              setPolygonPoints={setPolygonPoints}
              detailPoints={detailPoints}
              setDetailPoints={setDetailPoints}
              contourInterval={contourInterval}
              setContourInterval={setContourInterval}
              gridResolution={gridResolution}
              setGridResolution={setGridResolution}
            />
            {/* Layer Control Panel */}
            <LayerControl layers={layers} setLayers={setLayers} />
          </div>

          {/* Visualization & Results */}
          <div className="lg:col-span-2 space-y-8">
            <div className="flex gap-2 bg-card border border-border rounded-lg p-3">
              <button
                onClick={() => setShow3D(false)}
                className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors text-sm ${
                  !show3D ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-secondary/80"
                }`}
              >
                2D View
              </button>
              <button
                onClick={() => setShow3D(true)}
                className={`flex-1 px-4 py-2 rounded-lg font-medium transition-colors text-sm ${
                  show3D ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground hover:bg-secondary/80"
                }`}
              >
                3D View
              </button>
            </div>

            {/* Visualization */}
            {!show3D ? (
              <Visualization2D
                canvasRef={canvasRef}
                polygonPoints={polygonPoints}
                detailPoints={detailPoints}
                contourInterval={contourInterval}
                gridResolution={gridResolution}
                layers={layers}
              />
            ) : (
              <div className="bg-card rounded-lg border border-border p-6">
                <h2 className="text-xl font-bold text-foreground mb-4">3D Terrain Visualization</h2>
                <Visualization3D
                  polygonPoints={polygonPoints}
                  detailPoints={detailPoints}
                  gridResolution={gridResolution}
                />
              </div>
            )}

            <CalculatorResults polygonPoints={polygonPoints} detailPoints={detailPoints} canvasRef={canvasRef} />
          </div>
        </div>
      </div>
    </main>
  )
}
