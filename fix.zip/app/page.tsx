import Hero from "@/components/home/hero"
import Services from "@/components/home/services"
import CTA from "@/components/home/cta"

export default function Home() {
  return (
    <main>
      <Hero />
      <Services />
      <CTA />
    </main>
  )
}
