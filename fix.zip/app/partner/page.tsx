import Image from "next/image"

export default function Partner() {
  return (
    <main className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20">
        <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-8">Our Partner</h1>

        <div className="space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-foreground mb-6">Universitas Wijaya Kusuma Purwokerto</h2>

            <div className="flex flex-col sm:flex-row gap-8 items-start bg-card border border-border rounded-lg p-6">
              {/* Partner Logo */}
              <div className="flex-shrink-0 w-32 h-32 bg-blue-50 rounded-lg flex items-center justify-center border-2 border-primary/20">
                <Image
                  src="/images/image.png"
                  alt="Universitas Wijaya Kusuma Purwokerto Logo"
                  width={120}
                  height={120}
                  className="object-contain"
                />
              </div>

              {/* Partner Info */}
              <div className="flex-1">
                <p className="text-muted-foreground mb-4 leading-relaxed">
                  Universitas Wijaya Kusuma Purwokerto is a leading institution in engineering and education. Our
                  partnership combines academic expertise with practical industry application in surveying and mapping
                  technology.
                </p>

                <h3 className="text-lg font-bold text-foreground mb-3">Bentuk Kerja Sama</h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>Research & Development dalam teknologi surveying terkini</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>Training dan workshop untuk profesional surveying</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>Kolaborasi dalam proyek-proyek akademik dan praktis</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-primary font-bold">•</span>
                    <span>Mentoring untuk mahasiswa di bidang geomatics dan surveying</span>
                  </li>
                </ul>
              </div>
            </div>
          </section>

          <section className="bg-primary/5 border border-primary/10 rounded-lg p-6">
            <p className="text-foreground text-center">
              Kerjasama strategis ini memastikan MinaMetrics selalu mengikuti perkembangan terkini dalam teknologi
              surveying dan memberikan solusi terbaik kepada klien.
            </p>
          </section>
        </div>
      </div>
    </main>
  )
}
