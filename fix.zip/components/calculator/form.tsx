"use client"

import type React from "react"

import { useState } from "react"
import { calculateDetailPoint, parseCSV } from "@/lib/survey-utils"

interface PolygonPoint {
  name: string
  x: number
  y: number
  z: number
}

interface DetailPoint {
  name: string
  origin: string
  azimuth: number
  distance: number
  elevation: number
  x: number
  y: number
  z: number
}

interface IntervalDivisionMode {
  enabled: boolean
  startPoint: string
  endPoint: string
  intervals: number
}

interface Props {
  polygonPoints: PolygonPoint[]
  setPolygonPoints: (points: PolygonPoint[]) => void
  detailPoints: DetailPoint[]
  setDetailPoints: (points: DetailPoint[]) => void
  contourInterval: number
  setContourInterval: (interval: number) => void
  gridResolution: number
  setGridResolution: (resolution: number) => void
}

export default function CalculatorForm({
  polygonPoints,
  setPolygonPoints,
  detailPoints,
  setDetailPoints,
  contourInterval,
  setContourInterval,
  gridResolution,
  setGridResolution,
}: Props) {
  const [newDetailPoint, setNewDetailPoint] = useState({
    name: "",
    origin: polygonPoints[0]?.name || "A",
    azimuth: 0,
    distance: 0,
    elevation: 0,
  })

  const [calculatedCoordinates, setCalculatedCoordinates] = useState<{ x: number; y: number } | null>(null)

  const [useAlphaDelta, setUseAlphaDelta] = useState(false)
  const [alphaValue, setAlphaValue] = useState(0)
  const [deltaValue, setDeltaValue] = useState(0)

  const [intervalMode, setIntervalMode] = useState<IntervalDivisionMode>({
    enabled: false,
    startPoint: "",
    endPoint: "",
    intervals: 2,
  })

  const calculateCoordinates = () => {
    if (!newDetailPoint.name) {
      alert("Masukkan nama point terlebih dahulu")
      return
    }

    const originPoint = polygonPoints.find((p) => p.name === newDetailPoint.origin)
    if (!originPoint) return

    const { x, y } = calculateDetailPoint(originPoint.x, originPoint.y, newDetailPoint.azimuth, newDetailPoint.distance)
    setCalculatedCoordinates({ x, y })
  }

  const calculateWithAlphaDelta = () => {
    if (!newDetailPoint.name) {
      alert("Masukkan nama point terlebih dahulu")
      return
    }

    const originPoint = polygonPoints.find((p) => p.name === newDetailPoint.origin)
    if (!originPoint) return

    // Alpha: adjust azimuth from origin
    const adjustedAzimuth = newDetailPoint.azimuth - alphaValue

    // Delta: use distance as-is (already provided)
    const { x, y } = calculateDetailPoint(originPoint.x, originPoint.y, adjustedAzimuth, deltaValue)

    setCalculatedCoordinates({ x, y })
    setNewDetailPoint({
      ...newDetailPoint,
      distance: deltaValue,
      azimuth: adjustedAzimuth,
    })
  }

  const dividePointsIntoIntervals = () => {
    if (!intervalMode.startPoint || !intervalMode.endPoint || intervalMode.intervals < 2) {
      alert("Tentukan titik awal, akhir, dan jumlah interval")
      return
    }

    const startPoint = [...polygonPoints, ...detailPoints].find((p) => p.name === intervalMode.startPoint)
    const endPoint = [...polygonPoints, ...detailPoints].find((p) => p.name === intervalMode.endPoint)

    if (!startPoint || !endPoint) {
      alert("Titik tidak ditemukan")
      return
    }

    const newPoints: typeof detailPoints = []

    for (let i = 1; i < intervalMode.intervals; i++) {
      const ratio = i / intervalMode.intervals
      const interpPoint: (typeof detailPoints)[0] = {
        name: `${intervalMode.startPoint}_${intervalMode.endPoint}_${i}`,
        origin: startPoint.name,
        azimuth: 0,
        distance: 0,
        elevation: startPoint.z + ratio * (endPoint.z - startPoint.z),
        x: startPoint.x + ratio * (endPoint.x - startPoint.x),
        y: startPoint.y + ratio * (endPoint.y - startPoint.y),
        z: startPoint.z + ratio * (endPoint.z - startPoint.z),
      }
      newPoints.push(interpPoint)
    }

    setDetailPoints([...detailPoints, ...newPoints])
    setIntervalMode({
      enabled: false,
      startPoint: "",
      endPoint: "",
      intervals: 2,
    })
  }

  const addDetailPoint = () => {
    if (!calculatedCoordinates) return

    const point: DetailPoint = {
      name: newDetailPoint.name,
      origin: newDetailPoint.origin,
      azimuth: newDetailPoint.azimuth,
      distance: newDetailPoint.distance,
      elevation: newDetailPoint.elevation,
      x: calculatedCoordinates.x,
      y: calculatedCoordinates.y,
      z: newDetailPoint.elevation,
    }

    setDetailPoints([...detailPoints, point])
    setNewDetailPoint({
      name: "",
      origin: polygonPoints[0]?.name || "A",
      azimuth: 0,
      distance: 0,
      elevation: 0,
    })
    setCalculatedCoordinates(null)
    setUseAlphaDelta(false)
    setAlphaValue(0)
    setDeltaValue(0)
  }

  const deleteDetailPoint = (name: string) => {
    setDetailPoints(detailPoints.filter((p) => p.name !== name))
  }

  const handleCSVImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      const csv = event.target?.result as string
      try {
        const data = parseCSV(csv)
        const newPoints: DetailPoint[] = []

        data.forEach((row) => {
          const point: DetailPoint = {
            name: row.name || "",
            origin: row.origin || polygonPoints[0]?.name || "A",
            azimuth: Number.parseFloat(row.azimuth_deg) || 0,
            distance: Number.parseFloat(row.distance_m) || 0,
            elevation: Number.parseFloat(row.elevation_m) || 0,
            x: Number.parseFloat(row.x) || 0,
            y: Number.parseFloat(row.y) || 0,
            z: Number.parseFloat(row.z) || 0,
          }

          if (!point.x || !point.y) {
            const originPoint = polygonPoints.find((p) => p.name === point.origin)
            if (originPoint) {
              const { x, y } = calculateDetailPoint(originPoint.x, originPoint.y, point.azimuth, point.distance)
              point.x = x
              point.y = y
            }
          }

          if (point.name) newPoints.push(point)
        })

        setDetailPoints(newPoints)
      } catch (err) {
        console.error("Error importing CSV:", err)
        alert("Error importing CSV file")
      }
    }

    reader.readAsText(file)
  }

  const allPoints = [...polygonPoints, ...detailPoints]

  return (
    <div className="space-y-6">
      <div className="bg-primary/10 border border-primary/30 rounded-lg p-4">
        <h3 className="font-semibold text-foreground mb-2 text-sm">Cara Menggunakan:</h3>
        <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
          <li>Pilih Origin Point (A, B, atau C)</li>
          <li>Pilih mode: Standard (Azimuth + Distance) atau Alpha + Delta</li>
          <li>
            Masukkan <strong>Azimuth</strong> (0-360°) dan <strong>Distance</strong> (meter)
          </li>
          <li>
            Masukkan <strong>Elevation</strong> Z (meter) atau Alpha dan Delta jika menggunakan mode khusus
          </li>
          <li>Klik tombol Calculate untuk lihat hasil, lalu Add to Survey untuk menambahkan</li>
          <li>Atau gunakan fitur Interval Division untuk membagi otomatis antara dua titik</li>
        </ol>
      </div>

      <div className="bg-card rounded-lg border border-border p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Polygon Points</h2>
        <div className="space-y-2 text-sm">
          {polygonPoints.map((point) => (
            <div key={point.name} className="flex justify-between items-center p-2 bg-secondary/20 rounded">
              <span className="font-medium text-foreground">{point.name}:</span>
              <span className="text-muted-foreground font-mono">
                X={point.x.toFixed(1)} Y={point.y.toFixed(1)} Z={point.z.toFixed(1)}
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-card rounded-lg border border-border p-6">
        <div className="flex gap-2 mb-4 border-b border-border">
          <button
            onClick={() => setUseAlphaDelta(false)}
            className={`px-4 py-2 text-sm font-medium transition-colors ${
              !useAlphaDelta ? "border-b-2 border-primary text-primary" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Standard Mode
          </button>
          <button
            onClick={() => setUseAlphaDelta(true)}
            className={`px-4 py-2 text-sm font-medium transition-colors ${
              useAlphaDelta ? "border-b-2 border-primary text-primary" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            Alpha + Delta Mode
          </button>
        </div>

        <h2 className="text-lg font-bold text-foreground mb-4">
          {useAlphaDelta ? "Add Detail Point (Alpha + Delta)" : "Add Detail Point (Standard)"}
        </h2>

        <div className="space-y-3">
          <input
            type="text"
            placeholder="Point name (a1, b1, c1...)"
            value={newDetailPoint.name}
            onChange={(e) => setNewDetailPoint({ ...newDetailPoint, name: e.target.value })}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          />

          <select
            value={newDetailPoint.origin}
            onChange={(e) => setNewDetailPoint({ ...newDetailPoint, origin: e.target.value })}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          >
            {polygonPoints.map((p) => (
              <option key={p.name} value={p.name}>
                Origin {p.name}
              </option>
            ))}
          </select>

          {!useAlphaDelta ? (
            <>
              <div>
                <label className="text-xs text-muted-foreground block mb-2">
                  Azimuth: {newDetailPoint.azimuth.toFixed(0)}°
                </label>
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={newDetailPoint.azimuth}
                  onChange={(e) =>
                    setNewDetailPoint({
                      ...newDetailPoint,
                      azimuth: Number.parseFloat(e.target.value),
                    })
                  }
                  className="w-full"
                />
              </div>

              <input
                type="number"
                placeholder="Distance (m)"
                value={newDetailPoint.distance}
                onChange={(e) =>
                  setNewDetailPoint({
                    ...newDetailPoint,
                    distance: Number.parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />

              <input
                type="number"
                placeholder="Elevation Z (m)"
                value={newDetailPoint.elevation}
                onChange={(e) =>
                  setNewDetailPoint({
                    ...newDetailPoint,
                    elevation: Number.parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />

              {!calculatedCoordinates ? (
                <button
                  onClick={calculateCoordinates}
                  disabled={!newDetailPoint.name}
                  className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold text-base"
                >
                  🧮 Calculate Coordinates
                </button>
              ) : (
                <div className="bg-green-50 border border-green-300 rounded-lg p-4 space-y-2">
                  <p className="text-xs text-green-900 font-semibold">Koordinat Hasil Perhitungan:</p>
                  <div className="bg-white rounded p-2 font-mono text-sm text-green-900 space-y-1">
                    <div>X = {calculatedCoordinates.x.toFixed(2)} meter</div>
                    <div>Y = {calculatedCoordinates.y.toFixed(2)} meter</div>
                    <div>Z = {newDetailPoint.elevation.toFixed(2)} meter</div>
                  </div>
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={addDetailPoint}
                      className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold text-sm"
                    >
                      ✓ Add to Survey
                    </button>
                    <button
                      onClick={() => setCalculatedCoordinates(null)}
                      className="flex-1 px-4 py-2 bg-gray-400 text-white rounded-lg hover:bg-gray-500 transition-colors font-semibold text-sm"
                    >
                      ✕ Cancel
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              <div>
                <label className="text-xs text-muted-foreground block mb-2">
                  Azimuth Garis Utama: {newDetailPoint.azimuth.toFixed(0)}°
                </label>
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={newDetailPoint.azimuth}
                  onChange={(e) =>
                    setNewDetailPoint({
                      ...newDetailPoint,
                      azimuth: Number.parseFloat(e.target.value),
                    })
                  }
                  className="w-full"
                />
              </div>

              <div>
                <label className="text-xs text-muted-foreground block mb-2">
                  Alpha (Azimuth Adjustment): {alphaValue.toFixed(0)}°
                </label>
                <input
                  type="range"
                  min="-180"
                  max="180"
                  value={alphaValue}
                  onChange={(e) => setAlphaValue(Number.parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>

              <input
                type="number"
                placeholder="Delta - Distance (m)"
                value={deltaValue}
                onChange={(e) => setDeltaValue(Number.parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />

              <input
                type="number"
                placeholder="Elevation Z (m)"
                value={newDetailPoint.elevation}
                onChange={(e) =>
                  setNewDetailPoint({
                    ...newDetailPoint,
                    elevation: Number.parseFloat(e.target.value) || 0,
                  })
                }
                className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
              />

              {!calculatedCoordinates ? (
                <button
                  onClick={calculateWithAlphaDelta}
                  disabled={!newDetailPoint.name}
                  className="w-full px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold text-base"
                >
                  🧮 Calculate with Alpha + Delta
                </button>
              ) : (
                <div className="bg-green-50 border border-green-300 rounded-lg p-4 space-y-2">
                  <p className="text-xs text-green-900 font-semibold">Koordinat Hasil Perhitungan:</p>
                  <div className="bg-white rounded p-2 font-mono text-sm text-green-900 space-y-1">
                    <div>X = {calculatedCoordinates.x.toFixed(2)} meter</div>
                    <div>Y = {calculatedCoordinates.y.toFixed(2)} meter</div>
                    <div>Z = {newDetailPoint.elevation.toFixed(2)} meter</div>
                    <div className="pt-2 border-t border-green-200 text-xs">
                      Azimuth (adjusted): {(newDetailPoint.azimuth - alphaValue).toFixed(1)}°
                    </div>
                  </div>
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={addDetailPoint}
                      className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors font-semibold text-sm"
                    >
                      ✓ Add to Survey
                    </button>
                    <button
                      onClick={() => setCalculatedCoordinates(null)}
                      className="flex-1 px-4 py-2 bg-gray-400 text-white rounded-lg hover:bg-gray-500 transition-colors font-semibold text-sm"
                    >
                      ✕ Cancel
                    </button>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {detailPoints.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border">
            <p className="text-xs text-muted-foreground mb-2 font-semibold">
              Detail Points Added ({detailPoints.length})
            </p>
            <div className="space-y-1 max-h-40 overflow-y-auto">
              {detailPoints.map((p) => (
                <div key={p.name} className="flex justify-between items-center p-2 bg-secondary/10 rounded text-xs">
                  <span className="font-mono">{p.name}</span>
                  <button
                    onClick={() => deleteDetailPoint(p.name)}
                    className="text-destructive hover:text-destructive/90 font-medium"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="bg-card rounded-lg border border-border p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Interval Division</h2>
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">
            Bagi otomatis titik detail antara dua titik (awal dan akhir) dengan interval yang ditentukan
          </p>

          <select
            value={intervalMode.startPoint}
            onChange={(e) => setIntervalMode({ ...intervalMode, startPoint: e.target.value })}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">Pilih Titik Awal</option>
            {allPoints.map((p) => (
              <option key={p.name} value={p.name}>
                {p.name}
              </option>
            ))}
          </select>

          <select
            value={intervalMode.endPoint}
            onChange={(e) => setIntervalMode({ ...intervalMode, endPoint: e.target.value })}
            className="w-full px-3 py-2 border border-border rounded-lg bg-background text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">Pilih Titik Akhir</option>
            {allPoints.map((p) => (
              <option key={p.name} value={p.name}>
                {p.name}
              </option>
            ))}
          </select>

          <div>
            <label className="text-xs text-muted-foreground block mb-2">
              Jumlah Interval: {intervalMode.intervals}
            </label>
            <input
              type="range"
              min="2"
              max="10"
              value={intervalMode.intervals}
              onChange={(e) => setIntervalMode({ ...intervalMode, intervals: Number.parseInt(e.target.value) })}
              className="w-full"
            />
          </div>

          <button
            onClick={dividePointsIntoIntervals}
            disabled={!intervalMode.startPoint || !intervalMode.endPoint}
            className="w-full px-4 py-3 bg-orange-600 text-white rounded-lg hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-semibold text-base"
          >
            📊 Generate Interval Points
          </button>
        </div>
      </div>

      <div className="bg-card rounded-lg border border-border p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Import Data</h2>
        <label className="block">
          <span className="text-sm text-muted-foreground mb-2 block">
            Upload CSV (format: name, origin, azimuth_deg, distance_m, elevation_m)
          </span>
          <input
            type="file"
            accept=".csv"
            onChange={handleCSVImport}
            className="w-full text-sm text-muted-foreground file:mr-2 file:px-3 file:py-2 file:rounded-lg file:bg-primary file:text-primary-foreground file:cursor-pointer hover:file:bg-primary/90"
          />
        </label>
      </div>

      <div className="bg-card rounded-lg border border-border p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Visualization Settings</h2>
        <div className="space-y-4">
          <div>
            <label className="text-xs text-muted-foreground block mb-2">Contour Interval: {contourInterval}m</label>
            <input
              type="range"
              min="1"
              max="20"
              value={contourInterval}
              onChange={(e) => setContourInterval(Number.parseInt(e.target.value))}
              className="w-full"
            />
          </div>

          <div>
            <label className="text-xs text-muted-foreground block mb-2">Grid Resolution: {gridResolution}m</label>
            <input
              type="range"
              min="5"
              max="50"
              step="5"
              value={gridResolution}
              onChange={(e) => setGridResolution(Number.parseInt(e.target.value))}
              className="w-full"
            />
          </div>
        </div>
      </div>
    </div>
  )
}
