"use client"

import type React from "react"
import { generateCSV, calculateSurveyStatistics, downloadCanvasAsImage } from "@/lib/survey-utils"

interface PolygonPoint {
  name: string
  x: number
  y: number
  z: number
}

interface DetailPoint {
  name: string
  origin: string
  azimuth: number
  distance: number
  elevation: number
  x: number
  y: number
  z: number
}

interface Props {
  polygonPoints: PolygonPoint[]
  detailPoints: DetailPoint[]
  canvasRef?: React.RefObject<HTMLCanvasElement>
}

export default function CalculatorResults({ polygonPoints, detailPoints, canvasRef }: Props) {
  const stats = calculateSurveyStatistics([...polygonPoints, ...detailPoints])

  const downloadCSV = () => {
    const allPoints = [...polygonPoints, ...detailPoints]

    const rows = allPoints.map((p) => ({
      name: p.name,
      type: polygonPoints.find((pp) => pp.name === p.name) ? "Polygon" : "Detail",
      x: p.x.toFixed(3),
      y: p.y.toFixed(3),
      z: p.z.toFixed(3),
    }))

    const csv = generateCSV(["Name", "Type", "X (m)", "Y (m)", "Z (m)"], rows)

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `survey_data_${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  const downloadPNG = () => {
    if (!canvasRef?.current) {
      alert("Visualization not available")
      return
    }
    downloadCanvasAsImage(canvasRef.current, `survey_visualization_${new Date().toISOString().split("T")[0]}.png`)
  }

  const allPoints = [...polygonPoints, ...detailPoints]

  return (
    <div className="space-y-6">
      {/* Statistics Card */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Survey Statistics</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-secondary/20 rounded p-3">
            <p className="text-xs text-muted-foreground">Total Points</p>
            <p className="text-2xl font-bold text-foreground">{stats.totalPoints}</p>
          </div>
          <div className="bg-secondary/20 rounded p-3">
            <p className="text-xs text-muted-foreground">Elevation Range</p>
            <p className="text-2xl font-bold text-foreground">{stats.elevationRange.toFixed(2)}m</p>
          </div>
          <div className="bg-secondary/20 rounded p-3">
            <p className="text-xs text-muted-foreground">Avg. Elevation</p>
            <p className="text-2xl font-bold text-foreground">{stats.avgZ.toFixed(2)}m</p>
          </div>
          <div className="bg-secondary/20 rounded p-3">
            <p className="text-xs text-muted-foreground">Survey Area Span</p>
            <p className="text-2xl font-bold text-foreground">{stats.areaSpan.toFixed(2)}m</p>
          </div>
          <div className="bg-secondary/20 rounded p-3">
            <p className="text-xs text-muted-foreground">Min Z</p>
            <p className="text-xl font-bold text-foreground">{stats.minZ.toFixed(2)}</p>
          </div>
          <div className="bg-secondary/20 rounded p-3">
            <p className="text-xs text-muted-foreground">Max Z</p>
            <p className="text-xl font-bold text-foreground">{stats.maxZ.toFixed(2)}</p>
          </div>
        </div>
      </div>

      {/* Export Buttons */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Export Data</h2>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={downloadCSV}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors text-sm font-medium"
          >
            Download CSV
          </button>
          <button
            onClick={downloadPNG}
            className="px-4 py-2 bg-accent text-accent-foreground rounded-lg hover:bg-accent/90 transition-colors text-sm font-medium"
          >
            Export as PNG
          </button>
        </div>
      </div>

      {/* Results Table */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h2 className="text-lg font-bold text-foreground mb-4">Survey Results</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-3 font-semibold text-foreground">Point</th>
                <th className="text-left py-3 px-3 font-semibold text-foreground">Type</th>
                <th className="text-left py-3 px-3 font-semibold text-foreground">X (m)</th>
                <th className="text-left py-3 px-3 font-semibold text-foreground">Y (m)</th>
                <th className="text-left py-3 px-3 font-semibold text-foreground">Z (m)</th>
              </tr>
            </thead>
            <tbody>
              {polygonPoints.length > 0 && (
                <>
                  <tr className="border-b border-border/50 bg-secondary/20">
                    <td colSpan={5} className="py-2 px-3 font-semibold text-foreground">
                      Polygon Control Points
                    </td>
                  </tr>
                  {polygonPoints.map((point) => (
                    <tr key={point.name} className="border-b border-border/30 hover:bg-secondary/10 transition-colors">
                      <td className="py-3 px-3 font-mono text-foreground">{point.name}</td>
                      <td className="py-3 px-3 text-muted-foreground text-xs">Polygon</td>
                      <td className="py-3 px-3 text-foreground font-mono">{point.x.toFixed(3)}</td>
                      <td className="py-3 px-3 text-foreground font-mono">{point.y.toFixed(3)}</td>
                      <td className="py-3 px-3 text-foreground font-mono">{point.z.toFixed(3)}</td>
                    </tr>
                  ))}
                </>
              )}
              {detailPoints.length > 0 && (
                <>
                  <tr className="border-b border-border/50 bg-secondary/20">
                    <td colSpan={5} className="py-2 px-3 font-semibold text-foreground">
                      Detail Points (Calculated)
                    </td>
                  </tr>
                  {detailPoints.map((point) => (
                    <tr key={point.name} className="border-b border-border/30 hover:bg-secondary/10 transition-colors">
                      <td className="py-3 px-3 font-mono text-foreground">{point.name}</td>
                      <td className="py-3 px-3 text-muted-foreground text-xs">Detail</td>
                      <td className="py-3 px-3 text-foreground font-mono">{point.x.toFixed(3)}</td>
                      <td className="py-3 px-3 text-foreground font-mono">{point.y.toFixed(3)}</td>
                      <td className="py-3 px-3 text-foreground font-mono">{point.z.toFixed(3)}</td>
                    </tr>
                  ))}
                </>
              )}
              {allPoints.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-8 px-3 text-center text-muted-foreground">
                    No data to display. Add polygon and detail points to see results.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
