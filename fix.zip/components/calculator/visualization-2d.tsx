"use client"

import type React from "react"
import { useEffect, useRef as useCanvasRef, useState } from "react"
import {
  type Point,
  smoothContourPath,
  generateEdgeInterpolationPoints,
  getBoundaryPointsOrdered,
  createFullAreaInterpolationGrid,
  generateContourLevels,
  extractContoursFromGrid,
  calculateDistance,
  calculateAzimuth,
  generateNetworkColors,
} from "@/lib/survey-utils"

interface PolygonPoint {
  name: string
  x: number
  y: number
  z: number
}

interface DetailPoint {
  name: string
  origin: string
  azimuth: number
  distance: number
  elevation: number
  x: number
  y: number
  z: number
}

interface InterpolationPoint {
  name: string
  x: number
  y: number
  z: number
  between: [string, string]
}

interface Props {
  polygonPoints: PolygonPoint[]
  detailPoints: DetailPoint[]
  contourInterval: number
  gridResolution: number
  canvasRef?: React.RefObject<HTMLCanvasElement>
  layers?: {
    polygonPoints: boolean
    detailPoints: boolean
    interpolationPoints: boolean
    labels: boolean
    polygonLines: boolean
    detailLines: boolean
    contours: boolean
    networkEdges: boolean
  }
}

export default function Visualization2D({
  polygonPoints,
  detailPoints,
  contourInterval,
  gridResolution,
  canvasRef: externalRef,
  layers = {
    polygonPoints: true,
    detailPoints: true,
    interpolationPoints: true,
    labels: true,
    polygonLines: true,
    detailLines: true,
    contours: true,
    networkEdges: false,
  },
}: Props) {
  const internalRef = useCanvasRef<HTMLCanvasElement>(null)
  const canvasRef = externalRef || internalRef
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [hoveredPoint, setHoveredPoint] = useState<string | null>(null)
  const interpolationPoints: InterpolationPoint[] = generateEdgeInterpolationPoints(polygonPoints, detailPoints)

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height
    const padding = 60

    const allPoints: Point[] = [...polygonPoints, ...detailPoints]
    if (allPoints.length === 0) {
      ctx.fillStyle = "#f5f5f5"
      ctx.fillRect(0, 0, width, height)
      ctx.fillStyle = "#888"
      ctx.textAlign = "center"
      ctx.fillText("Add points to visualize", width / 2, height / 2)
      return
    }

    const boundaryMap = getBoundaryPointsOrdered(detailPoints, polygonPoints)

    let minX = Number.POSITIVE_INFINITY,
      maxX = Number.NEGATIVE_INFINITY
    let minY = Number.POSITIVE_INFINITY,
      maxY = Number.NEGATIVE_INFINITY

    allPoints.forEach((p) => {
      minX = Math.min(minX, p.x)
      maxX = Math.max(maxX, p.x)
      minY = Math.min(minY, p.y)
      maxY = Math.max(maxY, p.y)
    })

    const rangeX = maxX - minX || 1
    const rangeY = maxY - minY || 1
    const padRange = Math.max(rangeX, rangeY) * 0.15

    minX -= padRange
    maxX += padRange
    minY -= padRange
    maxY += padRange

    const scaleX = (width - 2 * padding) / (maxX - minX)
    const scaleY = (height - 2 * padding) / (maxY - minY)
    const scale = Math.min(scaleX, scaleY)

    const toCanvasX = (x: number) => padding + (x - minX) * scale * zoom + pan.x
    const toCanvasY = (y: number) => height - padding - (y - minY) * scale * zoom + pan.y

    const gradient = ctx.createLinearGradient(0, 0, 0, height)
    gradient.addColorStop(0, "#fefefe")
    gradient.addColorStop(1, "#f9f9f9")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    ctx.strokeStyle = "#e5e5e5"
    ctx.lineWidth = 0.8
    ctx.fillStyle = "#666"
    ctx.font = "11px monospace"
    ctx.textAlign = "center"

    let gridStep = 50
    while (gridStep * scale * zoom < 50) gridStep *= 2
    while (gridStep * scale * zoom > 120) gridStep /= 2

    if (zoom > 0.7) {
      for (let x = Math.ceil(minX / gridStep) * gridStep; x <= maxX; x += gridStep) {
        const canvasX = toCanvasX(x)
        ctx.beginPath()
        ctx.moveTo(canvasX, padding)
        ctx.lineTo(canvasX, height - padding)
        ctx.stroke()
        if (zoom > 1) {
          ctx.fillStyle = "#555"
          ctx.fillText(x.toFixed(0), canvasX, height - padding + 18)
        }
      }

      ctx.textAlign = "right"
      for (let y = Math.ceil(minY / gridStep) * gridStep; y <= maxY; y += gridStep) {
        const canvasY = toCanvasY(y)
        ctx.beginPath()
        ctx.moveTo(padding, canvasY)
        ctx.lineTo(width - padding, canvasY)
        ctx.stroke()
        if (zoom > 1) {
          ctx.fillStyle = "#555"
          ctx.fillText(y.toFixed(0), padding - 12, canvasY + 4)
        }
      }
    }

    ctx.strokeStyle = "#f0f0f0"
    ctx.lineWidth = 0.3
    const minorStep = gridStep / 5
    for (let x = Math.ceil(minX / minorStep) * minorStep; x <= maxX; x += minorStep) {
      const canvasX = toCanvasX(x)
      ctx.beginPath()
      ctx.moveTo(canvasX, padding)
      ctx.lineTo(canvasX, height - padding)
      ctx.stroke()
    }

    for (let y = Math.ceil(minY / minorStep) * minorStep; y <= maxY; y += minorStep) {
      const canvasY = toCanvasY(y)
      ctx.beginPath()
      ctx.moveTo(padding, canvasY)
      ctx.lineTo(width - padding, canvasY)
      ctx.stroke()
    }

    ctx.strokeStyle = "#333"
    ctx.lineWidth = 1.5
    ctx.beginPath()
    ctx.moveTo(padding, height - padding)
    ctx.lineTo(width - padding, height - padding)
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(padding, padding)
    ctx.lineTo(padding, height - padding)
    ctx.stroke()

    const allZ = allPoints.map((p) => p.z)
    const minZ = Math.min(...allZ)
    const maxZ = Math.max(...allZ)

    const resolution = gridResolution
    const { grid, xs, ys } = createFullAreaInterpolationGrid(allPoints, minX, maxX, minY, maxY, resolution)

    const contourLevels = generateContourLevels(minZ, maxZ, contourInterval)
    const contours = extractContoursFromGrid(grid, xs, ys, contourLevels)

    if (layers.contours) {
      ctx.strokeStyle = "#7a8a99"
      ctx.lineWidth = 1.2
      ctx.globalAlpha = 0.75

      contours.forEach((contour) => {
        if (contour.length < 2) return

        const smoothed = smoothContourPath(contour, 0.3)
        const elevation = contour[0].z

        ctx.beginPath()
        const start = smoothed[0]
        ctx.moveTo(toCanvasX(start.x), toCanvasY(start.y))

        for (let i = 1; i < smoothed.length; i++) {
          const prev = smoothed[i - 1]
          const curr = smoothed[i]

          if (
            prev.cp2x !== undefined &&
            prev.cp2y !== undefined &&
            curr.cp1x !== undefined &&
            curr.cp1y !== undefined
          ) {
            ctx.bezierCurveTo(
              toCanvasX(prev.cp2x),
              toCanvasY(prev.cp2y),
              toCanvasX(curr.cp1x),
              toCanvasY(curr.cp1y),
              toCanvasX(curr.x),
              toCanvasY(curr.y),
            )
          } else {
            ctx.lineTo(toCanvasX(curr.x), toCanvasY(curr.y))
          }
        }

        ctx.stroke()

        if (smoothed.length > 2 && zoom > 0.8) {
          const midIdx = Math.floor(smoothed.length / 2)
          const midPoint = smoothed[midIdx]
          ctx.fillStyle = "#556b7a"
          ctx.font = "bold 8px monospace"
          ctx.textAlign = "center"
          ctx.globalAlpha = 0.85
          ctx.fillText(`${elevation.toFixed(0)}m`, toCanvasX(midPoint.x), toCanvasY(midPoint.y))
          ctx.globalAlpha = 0.75
        }
      })

      ctx.globalAlpha = 1
    }

    if (layers.networkEdges && zoom > 1.5) {
      const networkPoints = [...polygonPoints, ...detailPoints, ...interpolationPoints]
      const edges: Array<{
        from: Point
        to: Point
        distance: number
        azimuth: number
      }> = []

      for (let i = 0; i < networkPoints.length; i++) {
        for (let j = i + 1; j < networkPoints.length; j++) {
          const p1 = networkPoints[i]
          const p2 = networkPoints[j]
          const dist = calculateDistance(p1.x, p1.y, p2.x, p2.y)
          const azimuth = calculateAzimuth(p1.x, p1.y, p2.x, p2.y)
          edges.push({ from: p1, to: p2, distance: dist, azimuth })
        }
      }

      const colors = generateNetworkColors(edges.length)
      edges.forEach((edge, idx) => {
        ctx.strokeStyle = colors[idx]
        ctx.lineWidth = 0.8
        ctx.globalAlpha = 0.4

        ctx.beginPath()
        ctx.moveTo(toCanvasX(edge.from.x), toCanvasY(edge.from.y))
        ctx.lineTo(toCanvasX(edge.to.x), toCanvasY(edge.to.y))
        ctx.stroke()

        if (zoom > 1.5) {
          const midX = (edge.from.x + edge.to.x) / 2
          const midY = (edge.from.y + edge.to.y) / 2
          const canvasMidX = toCanvasX(midX)
          const canvasMidY = toCanvasY(midY)

          ctx.fillStyle = colors[idx]
          ctx.font = "bold 6px monospace"
          ctx.textAlign = "center"
          ctx.globalAlpha = 0.7
          ctx.fillText(`${edge.distance.toFixed(1)}m`, canvasMidX, canvasMidY - 4)
          ctx.fillText(`${edge.azimuth.toFixed(0)}°`, canvasMidX, canvasMidY + 4)
          ctx.globalAlpha = 0.4
        }
      })
    }

    ctx.globalAlpha = 1

    if (layers.polygonLines && polygonPoints.length > 0) {
      ctx.strokeStyle = "#c41e3a"
      ctx.lineWidth = 2.8
      ctx.globalAlpha = 1
      ctx.beginPath()
      ctx.moveTo(toCanvasX(polygonPoints[0].x), toCanvasY(polygonPoints[0].y))
      for (let i = 1; i < polygonPoints.length; i++) {
        ctx.lineTo(toCanvasX(polygonPoints[i].x), toCanvasY(polygonPoints[i].y))
      }
      ctx.closePath()
      ctx.stroke()
    }

    if (layers.polygonPoints && polygonPoints.length > 0) {
      polygonPoints.forEach((p) => {
        ctx.fillStyle = "#c41e3a"
        ctx.beginPath()
        ctx.arc(toCanvasX(p.x), toCanvasY(p.y), 7, 0, 2 * Math.PI)
        ctx.fill()

        ctx.strokeStyle = "#8b0000"
        ctx.lineWidth = 2
        ctx.stroke()

        if (layers.labels) {
          const labelX = toCanvasX(p.x) + 12
          const labelY = toCanvasY(p.y) - 8

          ctx.fillStyle = "#000"
          ctx.font = "bold 12px monospace"
          ctx.textAlign = "left"
          ctx.fillText(p.name, labelX, labelY)

          if (zoom > 0.9) {
            ctx.font = "9px monospace"
            ctx.fillStyle = "#333"
            ctx.fillText(`X: ${p.x.toFixed(0)}`, labelX, labelY + 12)
            ctx.fillText(`Y: ${p.y.toFixed(0)}`, labelX, labelY + 21)
            ctx.fillText(`Z: ${p.z.toFixed(1)}m`, labelX, labelY + 30)
          }
        }
      })
    }

    if (layers.detailLines) {
      ctx.strokeStyle = "#22c55e"
      ctx.lineWidth = 1.5
      ctx.setLineDash([2, 2])
      ctx.globalAlpha = 0.4

      boundaryMap.forEach((points) => {
        if (points.length < 2) return
        ctx.beginPath()
        ctx.moveTo(toCanvasX(points[0].x), toCanvasY(points[0].y))
        for (let i = 1; i < points.length; i++) {
          ctx.lineTo(toCanvasX(points[i].x), toCanvasY(points[i].y))
        }
        ctx.stroke()
      })

      ctx.globalAlpha = 1
      ctx.setLineDash([])
    }

    if (layers.detailPoints && zoom > 0.7) {
      detailPoints.forEach((dp) => {
        ctx.fillStyle = "#22c55e"
        ctx.beginPath()
        ctx.arc(toCanvasX(dp.x), toCanvasY(dp.y), 5.5, 0, 2 * Math.PI)
        ctx.fill()

        ctx.strokeStyle = "#16a34a"
        ctx.lineWidth = 1.5
        ctx.stroke()

        if (layers.labels && (zoom > 1 || hoveredPoint === dp.name)) {
          let labelX = toCanvasX(dp.x) + 10
          const labelY = toCanvasY(dp.y) - 6

          if (dp.x > (minX + maxX) / 2) {
            labelX = toCanvasX(dp.x) - 60
          }

          ctx.fillStyle = "#000"
          ctx.font = "bold 10px monospace"
          ctx.textAlign = "left"
          ctx.fillText(dp.name, labelX, labelY)

          if (zoom > 1.1) {
            ctx.font = "8px monospace"
            ctx.fillStyle = "#555"
            ctx.fillText(`X: ${dp.x.toFixed(0)}`, labelX, labelY + 10)
            ctx.fillText(`Y: ${dp.y.toFixed(0)}`, labelX, labelY + 18)
            ctx.fillText(`Z: ${dp.z.toFixed(1)}m`, labelX, labelY + 26)
          }
        }
      })
    }

    if (layers.interpolationPoints && zoom > 0.8) {
      ctx.strokeStyle = "#3b82f6"
      ctx.lineWidth = 0.8
      ctx.globalAlpha = 0.5

      const groupedByEdge = new Map<string, Array<{ x: number; y: number; z: number }>>()
      interpolationPoints.forEach((ip) => {
        const key = `${ip.between[0]}-${ip.between[1]}`
        if (!groupedByEdge.has(key)) {
          groupedByEdge.set(key, [])
        }
        groupedByEdge.get(key)!.push(ip)
      })

      groupedByEdge.forEach((points) => {
        if (points.length > 0) {
          ctx.beginPath()
          ctx.moveTo(toCanvasX(points[0].x), toCanvasY(points[0].y))
          for (let i = 1; i < points.length; i++) {
            ctx.lineTo(toCanvasX(points[i].x), toCanvasY(points[i].y))
          }
          ctx.stroke()
        }
      })

      ctx.globalAlpha = 1

      interpolationPoints.forEach((ip) => {
        ctx.fillStyle = "#3b82f6"
        ctx.beginPath()
        ctx.arc(toCanvasX(ip.x), toCanvasY(ip.y), 3.5, 0, 2 * Math.PI)
        ctx.fill()

        ctx.strokeStyle = "#1e40af"
        ctx.lineWidth = 1
        ctx.stroke()

        if (layers.labels && zoom > 1.2) {
          let labelX = toCanvasX(ip.x) + 8
          const labelY = toCanvasY(ip.y) - 4

          if (ip.x > (minX + maxX) / 2) {
            labelX = toCanvasX(ip.x) - 40
          }

          ctx.fillStyle = "#000"
          ctx.font = "8px monospace"
          ctx.textAlign = "left"
          ctx.globalAlpha = 0.8
          ctx.fillText(ip.name, labelX, labelY)
          if (zoom > 1.5) {
            ctx.fillText(`Z: ${ip.z.toFixed(1)}m`, labelX, labelY + 8)
          }
          ctx.globalAlpha = 1
        }
      })
    }

    ctx.fillStyle = "#222"
    ctx.font = "bold 13px monospace"
    ctx.textAlign = "center"
    if (zoom > 0.8) {
      ctx.fillText("X (Easting) in meters", width / 2, height - 8)
    }

    ctx.save()
    ctx.translate(12, height / 2)
    ctx.rotate(-Math.PI / 2)
    ctx.textAlign = "center"
    if (zoom > 0.8) {
      ctx.fillText("Y (Northing) in meters", 0, 0)
    }
    ctx.restore()
  }, [polygonPoints, detailPoints, contourInterval, gridResolution, canvasRef, zoom, pan, layers, hoveredPoint])

  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault()
    const delta = e.deltaY > 0 ? 0.9 : 1.1
    const rect = e.currentTarget.getBoundingClientRect()
    const mouseX = e.clientX - rect.left
    const mouseY = e.clientY - rect.top

    const newZoom = zoom * delta
    const zoomDelta = 1 - 1 / delta

    setPan({
      x: pan.x - (mouseX * zoomDelta) / newZoom,
      y: pan.y - (mouseY * zoomDelta) / newZoom,
    })
    setZoom(Math.max(0.5, Math.min(3, newZoom)))
  }

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y })
  }

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) return
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleMouseLeave = () => {
    setHoveredPoint(null)
  }

  const handleMouseEnter = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const rect = canvas.getBoundingClientRect()
    const mouseX = e.clientX - rect.left
    const mouseY = e.clientY - rect.top

    const allPoints: Point[] = [...polygonPoints, ...detailPoints]
    const padding = 60

    let minX = Number.POSITIVE_INFINITY,
      maxX = Number.NEGATIVE_INFINITY
    let minY = Number.POSITIVE_INFINITY,
      maxY = Number.NEGATIVE_INFINITY

    allPoints.forEach((p) => {
      minX = Math.min(minX, p.x)
      maxX = Math.max(maxX, p.x)
      minY = Math.min(minY, p.y)
      maxY = Math.max(maxY, p.y)
    })

    const rangeX = maxX - minX || 1
    const rangeY = maxY - minY || 1
    const padRange = Math.max(rangeX, rangeY) * 0.15

    minX -= padRange
    maxX += padRange
    minY -= padRange
    maxY += padRange

    const scaleX = (canvas.width - 2 * padding) / (maxX - minX)
    const scaleY = (canvas.height - 2 * padding) / (maxY - minY)
    const scale = Math.min(scaleX, scaleY)

    const toCanvasX = (x: number) => padding + (x - minX) * scale * zoom + pan.x
    const toCanvasY = (y: number) => canvas.height - padding - (y - minY) * scale * zoom + pan.y

    allPoints.forEach((point) => {
      const x = toCanvasX(point.x)
      const y = toCanvasY(point.y)
      const radius = point.x === polygonPoints[0].x ? 7 : point.x === detailPoints[0].x ? 5.5 : 3.5

      if (Math.sqrt((mouseX - x) ** 2 + (mouseY - y) ** 2) < radius * zoom) {
        setHoveredPoint(point.name)
        return
      }
    })
  }

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <h2 className="text-xl font-bold text-foreground mb-4">2D Network Geometry Visualization</h2>
      <div className="mb-4 flex gap-2 text-xs">
        <button
          onClick={() => {
            setZoom(1)
            setPan({ x: 0, y: 0 })
          }}
          className="px-3 py-1 bg-secondary text-foreground rounded hover:bg-secondary/80"
        >
          Reset View
        </button>
        <span className="text-muted-foreground">Zoom: {(zoom * 100).toFixed(0)}% | Scroll to zoom, drag to pan</span>
      </div>
      <canvas
        ref={canvasRef}
        width={700}
        height={500}
        className="w-full border border-border rounded-lg bg-white shadow-sm cursor-move"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseLeave}
        onMouseEnter={handleMouseEnter}
      />
      <div className="flex flex-wrap gap-4 mt-4 text-xs text-muted-foreground">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-red-600 inline-block"></span>
          Polygon Points - A, B, C (Red)
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-green-500 inline-block"></span>
          Boundary Detail Points (Green)
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-blue-600 inline-block"></span>
          Interpolation Points (Blue)
        </div>
        <div className="flex items-center gap-2">
          <span className="w-4 h-0.5 bg-gray-600 inline-block"></span>
          Network Edges with Distance & Azimuth (Colored)
        </div>
        <div className="flex items-center gap-2">
          <span className="w-4 h-0.5 bg-gray-400 inline-block"></span>
          Contour Lines (Gray)
        </div>
      </div>
    </div>
  )
}
