"use client"
import { Eye, EyeOff } from "lucide-react"

interface LayerState {
  polygonPoints: boolean
  detailPoints: boolean
  interpolationPoints: boolean
  labels: boolean
  polygonLines: boolean
  detailLines: boolean
  contours: boolean
  networkEdges: boolean
}

interface LayerControlProps {
  layers: LayerState
  setLayers: (layers: LayerState) => void
}

export default function LayerControl({ layers, setLayers }: LayerControlProps) {
  const toggleLayer = (layer: keyof LayerState) => {
    setLayers({
      ...layers,
      [layer]: !layers[layer],
    })
  }

  const layerOptions: Array<{ key: keyof LayerState; label: string; color?: string }> = [
    { key: "polygonPoints", label: "Polygon Points (A, B, C)", color: "bg-red-600" },
    { key: "detailPoints", label: "Detail Points", color: "bg-green-500" },
    { key: "interpolationPoints", label: "Interpolation Points", color: "bg-blue-600" },
    { key: "labels", label: "All Labels" },
    { key: "polygonLines", label: "Polygon Lines", color: "bg-black" },
    { key: "detailLines", label: "Detail Lines", color: "bg-gray-400" },
    { key: "networkEdges", label: "Network Edges (Requires Zoom > 1.5x)" },
    { key: "contours", label: "Contour Lines", color: "bg-gray-600" },
  ]

  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <h3 className="text-sm font-bold text-foreground mb-3">Layer Control (GIS-Style)</h3>
      <div className="space-y-2">
        {layerOptions.map((option) => (
          <button
            key={option.key}
            onClick={() => toggleLayer(option.key)}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-secondary/50 transition-colors text-sm text-foreground"
          >
            {layers[option.key] ? (
              <Eye className="w-4 h-4 text-primary" />
            ) : (
              <EyeOff className="w-4 h-4 text-muted-foreground" />
            )}
            {option.color && <span className={`w-2 h-2 rounded-full ${option.color}`} />}
            <span className={layers[option.key] ? "font-medium" : "text-muted-foreground"}>{option.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}
