"use client"

import { useEffect, useRef } from "react"

interface Point {
  name: string
  x: number
  y: number
  z: number
}

interface Props {
  polygonPoints: Point[]
  detailPoints: Point[]
  gridResolution: number
}

export default function Visualization3D({ polygonPoints, detailPoints, gridResolution }: Props) {
  const containerRef = useRef<HTMLDivElement>(null)
  const rendererRef = useRef<any>(null)
  const sceneRef = useRef<any>(null)
  const animationIdRef = useRef<number | null>(null)

  useEffect(() => {
    if (!containerRef.current) return

    const allPoints = [...polygonPoints, ...detailPoints]
    if (allPoints.length === 0) return

    const loadThreeAndRender = async () => {
      try {
        const THREE = await import("three")
        const container = containerRef.current

        if (!container || !container.parentElement) return

        if (rendererRef.current) {
          if (container.contains(rendererRef.current.domElement)) {
            container.removeChild(rendererRef.current.domElement)
          }
          rendererRef.current.dispose()
          rendererRef.current = null
        }

        if (animationIdRef.current) {
          cancelAnimationFrame(animationIdRef.current)
          animationIdRef.current = null
        }

        const width = container.clientWidth || 800
        const height = container.clientHeight || 600

        // Scene setup
        const scene = new THREE.Scene()
        scene.background = new THREE.Color(0xf5f5f5)
        sceneRef.current = scene

        const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 10000)

        const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
        renderer.setSize(width, height)
        renderer.setPixelRatio(window.devicePixelRatio || 1)
        renderer.shadowMap.enabled = true
        rendererRef.current = renderer

        container.appendChild(renderer.domElement)

        // Find bounds for all points
        let minX = Number.POSITIVE_INFINITY,
          maxX = Number.NEGATIVE_INFINITY
        let minY = Number.POSITIVE_INFINITY,
          maxY = Number.NEGATIVE_INFINITY
        let minZ = Number.POSITIVE_INFINITY,
          maxZ = Number.NEGATIVE_INFINITY

        allPoints.forEach((p) => {
          minX = Math.min(minX, p.x)
          maxX = Math.max(maxX, p.x)
          minY = Math.min(minY, p.y)
          maxY = Math.max(maxY, p.y)
          minZ = Math.min(minZ, p.z)
          maxZ = Math.max(maxZ, p.z)
        })

        // Fallback bounds if all points are same
        if (minX === maxX) {
          minX -= 50
          maxX += 50
        }
        if (minY === maxY) {
          minY -= 50
          maxY += 50
        }
        if (minZ === maxZ) {
          minZ -= 5
          maxZ += 5
        }

        const centerX = (minX + maxX) / 2
        const centerY = (minY + maxY) / 2
        const centerZ = (minZ + maxZ) / 2
        const rangeX = maxX - minX
        const rangeY = maxY - minY
        const rangeZ = maxZ - minZ

        // Position camera
        const maxRange = Math.max(rangeX, rangeY, rangeZ)
        camera.position.set(maxRange * 0.7, maxRange * 0.5, maxRange * 0.7)
        camera.lookAt(centerX, centerZ, centerY)

        // Draw polygon as red wireframe
        if (polygonPoints.length > 0) {
          const polygonGeo = new THREE.BufferGeometry()
          const positions: number[] = []

          polygonPoints.forEach((p) => {
            positions.push(p.x - centerX, p.z - centerZ, p.y - centerY)
          })

          polygonGeo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(positions), 3))

          // Create polygon outline
          const indices: number[] = []
          for (let i = 0; i < polygonPoints.length; i++) {
            indices.push(i, (i + 1) % polygonPoints.length)
          }
          polygonGeo.setIndex(new THREE.BufferAttribute(new Uint32Array(indices), 1))

          const lineMaterial = new THREE.LineBasicMaterial({
            color: 0xdc3545,
            linewidth: 3,
          })
          const lineSegments = new THREE.LineSegments(polygonGeo, lineMaterial)
          scene.add(lineSegments)
        }

        // Draw detail points as dark spheres
        if (detailPoints.length > 0) {
          const pointGeo = new THREE.SphereGeometry(2, 8, 8)
          const pointMaterial = new THREE.MeshStandardMaterial({
            color: 0x1a1a1a,
            metalness: 0.3,
            roughness: 0.4,
          })

          detailPoints.forEach((p) => {
            const mesh = new THREE.Mesh(pointGeo, pointMaterial)
            mesh.position.set(p.x - centerX, p.z - centerZ, p.y - centerY)
            scene.add(mesh)
          })
        }

        // Create terrain mesh with IDW interpolation
        const steps = Math.max(10, Math.ceil(Math.sqrt(allPoints.length)) + 3)
        const terrainGeo = new THREE.BufferGeometry()
        const positions: number[] = []

        // Helper function for IDW interpolation
        const interpolateZ = (x: number, y: number): number => {
          let numerator = 0
          let denominator = 0
          const power = 2

          allPoints.forEach((p) => {
            const dx = x - p.x
            const dy = y - p.y
            const distance = Math.sqrt(dx * dx + dy * dy)

            if (distance < 0.01) {
              return (numerator = p.z)
            }

            const weight = 1 / Math.pow(distance, power)
            numerator += p.z * weight
            denominator += weight
          })

          return denominator > 0 ? numerator / denominator : (minZ + maxZ) / 2
        }

        // Create grid vertices
        for (let i = 0; i < steps; i++) {
          for (let j = 0; j < steps; j++) {
            const x = minX + (rangeX / (steps - 1)) * i
            const y = minY + (rangeY / (steps - 1)) * j
            const z = interpolateZ(x, y)

            positions.push(x - centerX, z - centerZ, y - centerY)
          }
        }

        terrainGeo.setAttribute("position", new THREE.BufferAttribute(new Float32Array(positions), 3))

        // Create terrain indices
        const indices: number[] = []
        for (let i = 0; i < steps - 1; i++) {
          for (let j = 0; j < steps - 1; j++) {
            const a = i * steps + j
            const b = i * steps + j + 1
            const c = (i + 1) * steps + j
            const d = (i + 1) * steps + j + 1

            indices.push(a, c, b)
            indices.push(b, c, d)
          }
        }

        terrainGeo.setIndex(new THREE.BufferAttribute(new Uint32Array(indices), 1))
        terrainGeo.computeVertexNormals()

        const terrainMaterial = new THREE.MeshPhongMaterial({
          color: 0xc5e3f0,
          specular: 0x111111,
          shininess: 200,
          side: THREE.DoubleSide,
        })

        const terrain = new THREE.Mesh(terrainGeo, terrainMaterial)
        terrain.castShadow = true
        terrain.receiveShadow = true
        scene.add(terrain)

        // Lighting
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5)
        scene.add(ambientLight)

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
        directionalLight.position.set(maxRange, maxRange, maxRange)
        directionalLight.castShadow = true
        scene.add(directionalLight)

        // Animation loop
        const animate = () => {
          animationIdRef.current = requestAnimationFrame(animate)
          terrain.rotation.y += 0.0003
          renderer.render(scene, camera)
        }
        animate()

        // Handle window resize
        const handleResize = () => {
          if (!container || !container.parentElement) return

          const newWidth = container.clientWidth || 800
          const newHeight = container.clientHeight || 600

          camera.aspect = newWidth / newHeight
          camera.updateProjectionMatrix()
          renderer.setSize(newWidth, newHeight)
        }

        window.addEventListener("resize", handleResize)

        return () => {
          window.removeEventListener("resize", handleResize)

          if (animationIdRef.current) {
            cancelAnimationFrame(animationIdRef.current)
            animationIdRef.current = null
          }

          if (rendererRef.current) {
            rendererRef.current.dispose()
            // Only remove from DOM if container still exists
            if (container && container.parentElement && container.contains(rendererRef.current.domElement)) {
              container.removeChild(rendererRef.current.domElement)
            }
            rendererRef.current = null
          }

          terrainGeo.dispose()
          terrainMaterial.dispose()
        }
      } catch (error) {
        console.error("[v0] Error loading Three.js:", error)
      }
    }

    loadThreeAndRender()

    return () => {
      if (animationIdRef.current) {
        cancelAnimationFrame(animationIdRef.current)
        animationIdRef.current = null
      }

      if (rendererRef.current && containerRef.current) {
        if (containerRef.current.contains(rendererRef.current.domElement)) {
          try {
            containerRef.current.removeChild(rendererRef.current.domElement)
          } catch (e) {
            // Silently fail if already removed
          }
        }
      }
    }
  }, [polygonPoints, detailPoints, gridResolution])

  return <div ref={containerRef} className="w-full h-96 border border-border rounded-lg bg-gray-50 shadow-sm" />
}
