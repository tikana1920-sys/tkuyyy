export default function Services() {
  const services = [
    {
      title: "Topographic Survey",
      description: "Detailed terrain mapping with elevation contours for land development and engineering",
      icon: "📍",
    },
    {
      title: "Polygon & Control Points",
      description: "Precision control point establishment for accurate project reference frames",
      icon: "🎯",
    },
    {
      title: "Contour Mapping",
      description: "Professional contour generation with customizable intervals and visualization",
      icon: "📊",
    },
    {
      title: "Situation Mapping",
      description: "Comprehensive site mapping including infrastructure and boundary delineation",
      icon: "🗺️",
    },
    {
      title: "GIS Services",
      description: "Geographic information system analysis and spatial data management",
      icon: "🌍",
    },
    {
      title: "Data Processing",
      description: "Advanced processing of survey data with quality assurance and validation",
      icon: "⚙️",
    },
  ]

  return (
    <section className="py-20 sm:py-28 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-foreground mb-4">Our Services</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive surveying and mapping solutions tailored to your project needs
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div key={index} className="p-6 bg-card rounded-lg border border-border hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-xl font-bold text-foreground mb-2">{service.title}</h3>
              <p className="text-muted-foreground">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
