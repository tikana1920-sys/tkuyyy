import Link from "next/link"

export default function Hero() {
  return (
    <section className="relative py-20 sm:py-28 bg-gradient-to-br from-primary/10 to-accent/10 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-4 text-balance">
            MinaMetrics - Professional Surveying & Mapping
          </h1>
          <p className="text-lg sm:text-xl text-muted-foreground mb-8 text-balance">
            Precision geodesy, topography, and mapping solutions for engineering projects. Advanced surveying technology
            meets professional expertise.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/services"
              className="px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium inline-block"
            >
              Explore Services
            </Link>
            <Link
              href="/calculator"
              className="px-6 py-3 bg-accent text-accent-foreground rounded-lg hover:bg-accent/90 transition-colors font-medium inline-block"
            >
              Try Calculator
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
