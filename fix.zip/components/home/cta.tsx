import Link from "next/link"

export default function CTA() {
  return (
    <section className="py-20 sm:py-28 bg-gradient-to-r from-primary/5 to-accent/5 border-t border-border">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">Ready to Get Started?</h2>
        <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
          Try our interactive calculator to compute survey coordinates, generate contours, and visualize your data in 2D
          or 3D
        </p>
        <Link
          href="/calculator"
          className="inline-block px-8 py-3 bg-accent text-accent-foreground rounded-lg hover:bg-accent/90 transition-colors font-medium text-lg"
        >
          Access Calculator
        </Link>
      </div>
    </section>
  )
}
