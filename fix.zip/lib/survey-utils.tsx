export interface Point {
  name: string
  x: number
  y: number
  z: number
}

export interface DetailPoint extends Point {
  origin: string
  azimuth: number
  distance: number
  elevation: number
}

// Inverse Distance Weighting (IDW) interpolation
export function idwInterpolation(x: number, y: number, points: Point[], power = 2): number {
  if (points.length === 0) return 0
  if (points.length === 1) return points[0].z

  let totalWeight = 0
  let totalValue = 0

  points.forEach((point) => {
    const distance = Math.sqrt((x - point.x) ** 2 + (y - point.y) ** 2)

    if (distance < 0.01) return point.z

    const weight = 1 / distance ** power
    totalWeight += weight
    totalValue += weight * point.z
  })

  return totalValue / totalWeight
}

// Create a grid of interpolated Z values
export function createInterpolationGrid(
  points: Point[],
  minX: number,
  maxX: number,
  minY: number,
  maxY: number,
  resolution: number,
): number[][] {
  const cols = Math.ceil((maxX - minX) / resolution) + 1
  const rows = Math.ceil((maxY - minY) / resolution) + 1

  const grid: number[][] = []

  for (let i = 0; i < rows; i++) {
    const row: number[] = []
    for (let j = 0; j < cols; j++) {
      const x = minX + j * resolution
      const y = minY + i * resolution
      row.push(idwInterpolation(x, y, points, 2))
    }
    grid.push(row)
  }

  return grid
}

// Marching squares algorithm for contour extraction
export function extractContours(
  grid: number[][],
  minX: number,
  minY: number,
  resolution: number,
  levels: number[],
): Array<Array<{ x: number; y: number }>> {
  const contours: Array<Array<{ x: number; y: number }>> = []

  levels.forEach((level) => {
    const contourSegments: Array<Array<{ x: number; y: number }>> = []
    const edgesProcessed = new Set<string>()

    for (let i = 0; i < grid.length - 1; i++) {
      for (let j = 0; j < grid[i].length - 1; j++) {
        const z1 = grid[i][j]
        const z2 = grid[i][j + 1]
        const z3 = grid[i + 1][j + 1]
        const z4 = grid[i + 1][j]

        const cellX = minX + j * resolution
        const cellY = minY + i * resolution

        // Calculate intersection points on cell edges
        const intersections: Array<{ x: number; y: number; edge: number }> = []

        // Top edge
        if ((z1 < level && z2 >= level) || (z1 >= level && z2 < level)) {
          const t = (level - z1) / (z2 - z1)
          intersections.push({
            x: cellX + t * resolution,
            y: cellY,
            edge: 0,
          })
        }

        // Right edge
        if ((z2 < level && z3 >= level) || (z2 >= level && z3 < level)) {
          const t = (level - z2) / (z3 - z2)
          intersections.push({
            x: cellX + resolution,
            y: cellY + t * resolution,
            edge: 1,
          })
        }

        // Bottom edge
        if ((z4 < level && z3 >= level) || (z4 >= level && z3 < level)) {
          const t = (level - z4) / (z3 - z4)
          intersections.push({
            x: cellX + (1 - t) * resolution,
            y: cellY + resolution,
            edge: 2,
          })
        }

        // Left edge
        if ((z1 < level && z4 >= level) || (z1 >= level && z4 < level)) {
          const t = (level - z1) / (z4 - z1)
          intersections.push({
            x: cellX,
            y: cellY + t * resolution,
            edge: 3,
          })
        }

        if (intersections.length === 2) {
          const segment = [intersections[0], intersections[1]].map((p) => ({ x: p.x, y: p.y }))
          contourSegments.push(segment)
        }
      }
    }

    // Connect segments into continuous lines
    if (contourSegments.length > 0) {
      const contourPath: Array<{ x: number; y: number }> = []
      const used = new Set<number>()

      while (used.size < contourSegments.length) {
        if (contourPath.length === 0 && used.size < contourSegments.length) {
          const firstUnused = Array.from({ length: contourSegments.length }).findIndex((_, i) => !used.has(i))
          if (firstUnused !== -1) {
            contourPath.push(...contourSegments[firstUnused])
            used.add(firstUnused)
          }
        }

        let found = false
        const lastPoint = contourPath[contourPath.length - 1]
        for (let i = 0; i < contourSegments.length; i++) {
          if (used.has(i)) continue

          const seg = contourSegments[i]
          const dist1 = Math.hypot(seg[0].x - lastPoint.x, seg[0].y - lastPoint.y)
          const dist2 = Math.hypot(seg[1].x - lastPoint.x, seg[1].y - lastPoint.y)

          if (dist1 < 1) {
            contourPath.push(seg[1])
            used.add(i)
            found = true
            break
          } else if (dist2 < 1) {
            contourPath.push(seg[0])
            used.add(i)
            found = true
            break
          }
        }

        if (!found) break
      }

      if (contourPath.length > 1) {
        contours.push(contourPath)
      }
    }
  })

  return contours
}

// Generate contour levels based on min, max, and interval
export function generateContourLevels(minZ: number, maxZ: number, interval: number): number[] {
  const levels: number[] = []
  const startLevel = Math.ceil(minZ / interval) * interval

  for (let z = startLevel; z <= maxZ; z += interval) {
    levels.push(z)
  }

  return levels
}

// Coordinate transformation: azimuth and distance to x,y
export function calculateDetailPoint(
  originX: number,
  originY: number,
  azimuth: number,
  distance: number,
): { x: number; y: number } {
  const azimuthRad = (azimuth * Math.PI) / 180
  const x = originX + distance * Math.sin(azimuthRad)
  const y = originY + distance * Math.cos(azimuthRad)

  return { x, y }
}

// CSV parsing
export function parseCSV(csv: string): Array<Record<string, string>> {
  const lines = csv.trim().split("\n")
  if (lines.length < 2) return []

  const headers = lines[0].split(",").map((h) => h.trim())
  const data = lines.slice(1).map((line) => {
    const values = line.split(",").map((v) => v.trim())
    const obj: Record<string, string> = {}
    headers.forEach((header, index) => {
      obj[header] = values[index] || ""
    })
    return obj
  })

  return data
}

// CSV generation
export function generateCSV(headers: string[], rows: Array<Record<string, any>>): string {
  const csvHeaders = headers.join(",")
  const csvRows = rows.map((row) => headers.map((header) => row[header] ?? "").join(","))
  return [csvHeaders, ...csvRows].join("\n")
}

// Canvas export functionality
export function downloadCanvasAsImage(canvas: HTMLCanvasElement, filename = "survey-visualization.png"): void {
  canvas.toBlob((blob) => {
    if (!blob) return
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = filename
    a.click()
    window.URL.revokeObjectURL(url)
  })
}

export function downloadCanvasAsSVG(canvas: HTMLCanvasElement, filename = "survey-visualization.svg"): void {
  const svg = `<svg width="${canvas.width}" height="${canvas.height}" xmlns="http://www.w3.org/2000/svg">
    <image width="${canvas.width}" height="${canvas.height}" href="${canvas.toDataURL()}" />
  </svg>`

  const blob = new Blob([svg], { type: "image/svg+xml" })
  const url = window.URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  window.URL.revokeObjectURL(url)
}

// Survey statistics calculator
export function calculateSurveyStatistics(points: Point[]) {
  if (points.length === 0) {
    return {
      totalPoints: 0,
      minZ: 0,
      maxZ: 0,
      avgZ: 0,
      minX: 0,
      maxX: 0,
      minY: 0,
      maxY: 0,
      areaSpan: 0,
      elevationRange: 0,
    }
  }

  const zValues = points.map((p) => p.z)
  const xValues = points.map((p) => p.x)
  const yValues = points.map((p) => p.y)

  const minZ = Math.min(...zValues)
  const maxZ = Math.max(...zValues)
  const avgZ = zValues.reduce((a, b) => a + b, 0) / points.length

  const minX = Math.min(...xValues)
  const maxX = Math.max(...xValues)
  const minY = Math.min(...yValues)
  const maxY = Math.max(...yValues)

  const areaSpan = Math.sqrt((maxX - minX) ** 2 + (maxY - minY) ** 2)
  const elevationRange = maxZ - minZ

  return {
    totalPoints: points.length,
    minZ: Math.round(minZ * 100) / 100,
    maxZ: Math.round(maxZ * 100) / 100,
    avgZ: Math.round(avgZ * 100) / 100,
    minX: Math.round(minX * 100) / 100,
    maxX: Math.round(maxX * 100) / 100,
    minY: Math.round(minY * 100) / 100,
    maxY: Math.round(maxY * 100) / 100,
    areaSpan: Math.round(areaSpan * 100) / 100,
    elevationRange: Math.round(elevationRange * 100) / 100,
  }
}

function sign(p1: Point, p2: Point, p3: Point): number {
  return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y)
}

export function delaunayTriangulation(points: Point[]): Array<[number, number, number]> {
  if (points.length < 3) return []

  const triangles: Array<[number, number, number]> = []
  const pointIndices = points.map((_, i) => i)

  // Simple O(n^3) Delaunay implementation for visualization
  for (let i = 0; i < pointIndices.length; i++) {
    for (let j = i + 1; j < pointIndices.length; j++) {
      for (let k = j + 1; k < pointIndices.length; k++) {
        const p1 = points[i]
        const p2 = points[j]
        const p3 = points[k]

        // Check if any other point is inside circumcircle
        let isValid = true
        for (let m = 0; m < points.length; m++) {
          if (m === i || m === j || m === k) continue

          const d1 = sign(points[m], p1, p2)
          const d2 = sign(points[m], p2, p3)
          const d3 = sign(points[m], p3, p1)

          if ((d1 > 0 && d2 > 0 && d3 > 0) || (d1 < 0 && d2 < 0 && d3 < 0)) {
            isValid = false
            break
          }
        }

        if (isValid) {
          triangles.push([i, j, k])
        }
      }
    }
  }

  return triangles
}

export function smoothContourPath(
  points: Array<{ x: number; y: number }>,
  tension = 0.5,
): Array<{ x: number; y: number; cp1x?: number; cp1y?: number; cp2x?: number; cp2y?: number }> {
  if (points.length < 2) return points

  const smoothed: Array<{ x: number; y: number; cp1x?: number; cp1y?: number; cp2x?: number; cp2y?: number }> = []

  for (let i = 0; i < points.length; i++) {
    const prev = i > 0 ? points[i - 1] : points[i]
    const curr = points[i]
    const next = i < points.length - 1 ? points[i + 1] : points[i]

    // Catmull-Rom control points
    const cp1x = curr.x + (next.x - prev.x) * tension
    const cp1y = curr.y + (next.y - prev.y) * tension

    smoothed.push({
      x: curr.x,
      y: curr.y,
      cp1x,
      cp1y,
    })
  }

  // Set backward control points
  for (let i = 0; i < smoothed.length - 1; i++) {
    const curr = smoothed[i]
    const next = smoothed[i + 1]

    const tension_factor = 0.25
    curr.cp2x = next.x - (next.cp1x ?? next.x - curr.x) * tension_factor
    curr.cp2y = next.y - (next.cp1y ?? next.y - curr.y) * tension_factor
  }

  return smoothed
}

export function generateInterpolationPoints(
  detailPoints: Point[],
): Array<{ x: number; y: number; z: number; between: [string, string]; originalElevation?: number }> {
  const interpolationPoints: Array<{
    x: number
    y: number
    z: number
    between: [string, string]
    originalElevation?: number
  }> = []

  for (let i = 0; i < detailPoints.length; i++) {
    for (let j = i + 1; j < detailPoints.length; j++) {
      const p1 = detailPoints[i]
      const p2 = detailPoints[j]

      const elevDiff = Math.abs(p2.z - p1.z)
      let interval = 5 // Default interval untuk kelipatan 5

      // Determine interpolation interval
      if (elevDiff >= 50) {
        interval = 10 // Selisih puluhan, gunakan interval 10
      } else if (elevDiff >= 20) {
        interval = 5 // Selisih 20-50, gunakan interval 5
      } else if (elevDiff >= 10) {
        interval = 2 // Selisih 10-20, gunakan interval 2
      } else {
        interval = 1 // Selisih kecil, gunakan interval 1
      }

      // Generate interpolation points
      const minZ = Math.min(p1.z, p2.z)
      const maxZ = Math.max(p1.z, p2.z)

      for (let z = minZ + interval; z < maxZ; z += interval) {
        const ratio = (z - p1.z) / (p2.z - p1.z)
        const interpPoint = {
          x: p1.x + ratio * (p2.x - p1.x),
          y: p1.y + ratio * (p2.y - p1.y),
          z: z,
          between: [p1.name, p2.name] as [string, string],
        }
        interpolationPoints.push(interpPoint)
      }
    }
  }

  return interpolationPoints
}

function crossProduct(o: Point, a: Point, b: Point): number {
  return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x)
}

export function convexHull(points: Point[]): Point[] {
  if (points.length <= 3) return points

  // Sort points lexicographically (first by x, then by y)
  const sorted = [...points].sort((a, b) => a.x - b.x || a.y - b.y)

  // Build lower hull
  const lower: Point[] = []
  for (const p of sorted) {
    while (lower.length >= 2 && crossProduct(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) {
      lower.pop()
    }
    lower.push(p)
  }

  // Build upper hull
  const upper: Point[] = []
  for (let i = sorted.length - 1; i >= 0; i--) {
    const p = sorted[i]
    while (upper.length >= 2 && crossProduct(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) {
      upper.pop()
    }
    upper.push(p)
  }

  // Remove the last point of each half because it's repeated
  lower.pop()
  upper.pop()

  return lower.concat(upper)
}

export function createBoundaryContouring(
  points: Point[],
  minZ: number,
  maxZ: number,
  contourInterval: number,
): Array<Array<{ x: number; y: number; z: number }>> {
  const boundaryContours: Array<Array<{ x: number; y: number; z: number }>> = []

  // Get convex hull
  const hull = convexHull(points)

  if (hull.length < 2) return boundaryContours

  const contourLevels = generateContourLevels(minZ, maxZ, contourInterval)

  // For each contour level, interpolate points along boundary edges
  contourLevels.forEach((level) => {
    const contourPoints: Array<{ x: number; y: number; z: number }> = []

    // For each edge of the hull, find interpolation points at this elevation
    for (let i = 0; i < hull.length; i++) {
      const p1 = hull[i]
      const p2 = hull[(i + 1) % hull.length]

      const z1 = p1.z
      const z2 = p2.z

      // Check if contour level crosses this edge
      if ((z1 <= level && z2 >= level) || (z1 >= level && z2 <= level)) {
        if (Math.abs(z2 - z1) < 0.01) continue // Avoid division by zero

        const t = (level - z1) / (z2 - z1)
        const interpPoint = {
          x: p1.x + t * (p2.x - p1.x),
          y: p1.y + t * (p2.y - p1.y),
          z: level,
        }
        contourPoints.push(interpPoint)
      }
    }

    // Also include hull points that are at or very close to this level
    hull.forEach((p) => {
      if (Math.abs(p.z - level) < 1) {
        if (!contourPoints.some((cp) => Math.abs(cp.x - p.x) < 0.1 && Math.abs(cp.y - p.y) < 0.1)) {
          contourPoints.push({ x: p.x, y: p.y, z: p.z })
        }
      }
    })

    if (contourPoints.length >= 2) {
      boundaryContours.push(contourPoints)
    }
  })

  return boundaryContours
}

export function generateBoundaryInterpolationPoints(
  polygonPoints: Point[],
  detailPoints: Point[],
): Array<{ name: string; x: number; y: number; z: number; between: [string, string] }> {
  const interpolationPoints: Array<{ name: string; x: number; y: number; z: number; between: [string, string] }> = []

  // Get boundary points (polygon + detail points on hull)
  const allPoints = [...polygonPoints, ...detailPoints]
  const hull = convexHull(allPoints)

  // For each edge on the hull boundary
  for (let i = 0; i < hull.length; i++) {
    const p1 = hull[i]
    const p2 = hull[(i + 1) % hull.length]

    const elevDiff = Math.abs(p2.z - p1.z)
    let interval = 5

    // Determine interpolation interval based on elevation difference
    if (elevDiff >= 50) {
      interval = 10
    } else if (elevDiff >= 20) {
      interval = 5
    } else if (elevDiff >= 10) {
      interval = 2
    } else {
      interval = 1
    }

    // Generate interpolation points along this edge
    const minZ = Math.min(p1.z, p2.z)
    const maxZ = Math.max(p1.z, p2.z)

    for (let z = minZ + interval; z < maxZ; z += interval) {
      const t = (z - p1.z) / (p2.z - p1.z)
      const interpPoint = {
        name: `${p1.name}_${p2.name}_${z.toFixed(0)}`,
        x: p1.x + t * (p2.x - p1.x),
        y: p1.y + t * (p2.y - p1.y),
        z: z,
        between: [p1.name, p2.name] as [string, string],
      }
      interpolationPoints.push(interpPoint)
    }
  }

  return interpolationPoints
}

export function getBoundaryPointsForPolygon(detailPoints: Point[], polygonPoints: Point[]): Map<string, Point[]> {
  const boundaryMap = new Map<string, Point[]>()

  // Initialize map with polygon names
  polygonPoints.forEach((p) => {
    boundaryMap.set(p.name, [])
  })

  // Assign detail points to their closest polygon vertex
  detailPoints.forEach((dp) => {
    let closestPoly = polygonPoints[0]
    let minDist = Number.POSITIVE_INFINITY

    polygonPoints.forEach((p) => {
      const dist = Math.sqrt((dp.x - p.x) ** 2 + (dp.y - p.y) ** 2)
      if (dist < minDist) {
        minDist = dist
        closestPoly = p
      }
    })

    const key = closestPoly.name
    if (!boundaryMap.has(key)) {
      boundaryMap.set(key, [])
    }
    boundaryMap.get(key)!.push(dp)
  })

  return boundaryMap
}

export function generateEdgeInterpolationPoints(
  polygonPoints: Point[],
  detailPoints: Point[],
): Array<{
  name: string
  x: number
  y: number
  z: number
  between: [string, string]
  type: "polygon_edge" | "boundary"
}> {
  const interpolationPoints: Array<{
    name: string
    x: number
    y: number
    z: number
    between: [string, string]
    type: "polygon_edge" | "boundary"
  }> = []

  const boundaryMap = getBoundaryPointsForPolygon(detailPoints, polygonPoints)

  // For each polygon edge (A-B, B-C, C-A)
  for (let i = 0; i < polygonPoints.length; i++) {
    const p1 = polygonPoints[i]
    const p2 = polygonPoints[(i + 1) % polygonPoints.length]

    // Get boundary points associated with this edge
    const edgeStart = boundaryMap.get(p1.name) || []
    const edgeEnd = boundaryMap.get(p2.name) || []

    // Interpolate between start polygon and end polygon
    const elevDiff = Math.abs(p2.z - p1.z)
    let interval = 5

    if (elevDiff >= 50) {
      interval = 10
    } else if (elevDiff >= 20) {
      interval = 5
    } else if (elevDiff >= 10) {
      interval = 2
    } else {
      interval = 1
    }

    const minZ = Math.min(p1.z, p2.z)
    const maxZ = Math.max(p1.z, p2.z)

    for (let z = minZ + interval; z < maxZ; z += interval) {
      const t = (z - p1.z) / (p2.z - p1.z)
      const interpPoint = {
        name: `${p1.name}_${p2.name}_${z.toFixed(0)}`,
        x: p1.x + t * (p2.x - p1.x),
        y: p1.y + t * (p2.y - p1.y),
        z: z,
        between: [p1.name, p2.name] as [string, string],
        type: "polygon_edge" as const,
      }
      interpolationPoints.push(interpPoint)
    }
  }

  return interpolationPoints
}

export function getBoundaryPointsOrdered(detailPoints: Point[], polygonPoints: Point[]): Map<string, Point[]> {
  const boundaryMap = new Map<string, Point[]>()

  // Initialize map with each polygon name
  polygonPoints.forEach((p) => {
    boundaryMap.set(p.name, [])
  })

  // Assign detail points to their closest polygon vertex
  detailPoints.forEach((dp) => {
    let closestPoly = polygonPoints[0]
    let minDist = Number.POSITIVE_INFINITY

    polygonPoints.forEach((p) => {
      const dist = Math.sqrt((dp.x - p.x) ** 2 + (dp.y - p.y) ** 2)
      if (dist < minDist) {
        minDist = dist
        closestPoly = p
      }
    })

    const key = closestPoly.name
    if (!boundaryMap.has(key)) {
      boundaryMap.set(key, [])
    }
    boundaryMap.get(key)!.push(dp)
  })

  // Sort points within each group by distance from polygon vertex (radial order)
  boundaryMap.forEach((points, key) => {
    const polyPoint = polygonPoints.find((p) => p.name === key)!
    points.sort((a, b) => {
      const distA = Math.sqrt((a.x - polyPoint.x) ** 2 + (a.y - polyPoint.y) ** 2)
      const distB = Math.sqrt((b.x - polyPoint.x) ** 2 + (b.y - polyPoint.y) ** 2)
      return distA - distB
    })
  })

  return boundaryMap
}

export function createFullAreaInterpolationGrid(
  points: Point[],
  minX: number,
  maxX: number,
  minY: number,
  maxY: number,
  resolution: number,
): { grid: number[][]; xs: number[]; ys: number[] } {
  const xs: number[] = []
  const ys: number[] = []
  const grid: number[][] = []

  for (let x = minX; x <= maxX; x += resolution) {
    xs.push(x)
  }
  for (let y = minY; y <= maxY; y += resolution) {
    ys.push(y)
  }

  for (const y of ys) {
    const row: number[] = []
    for (const x of xs) {
      row.push(idwInterpolation(x, y, points, 2))
    }
    grid.push(row)
  }

  return { grid, xs, ys }
}

export function extractContoursFromGrid(
  grid: number[][],
  xs: number[],
  ys: number[],
  levels: number[],
): Array<Array<{ x: number; y: number; z: number }>> {
  const contours: Array<Array<{ x: number; y: number; z: number }>> = []

  for (const level of levels) {
    const points: Array<{ x: number; y: number; z: number }> = []

    for (let i = 0; i < grid.length - 1; i++) {
      for (let j = 0; j < grid[i].length - 1; j++) {
        const z1 = grid[i][j]
        const z2 = grid[i][j + 1]
        const z3 = grid[i + 1][j + 1]
        const z4 = grid[i + 1][j]

        const x1 = xs[j]
        const x2 = xs[j + 1]
        const y1 = ys[i]
        const y2 = ys[i + 1]

        // Check all four edges for contour crossings
        const edges = [
          { z_a: z1, z_b: z2, x_a: x1, x_b: x2, y_a: y1, y_b: y1 }, // top
          { z_a: z2, z_b: z3, x_a: x2, x_b: x2, y_a: y1, y_b: y2 }, // right
          { z_a: z4, z_b: z3, x_a: x1, x_b: x2, y_a: y2, y_b: y2 }, // bottom
          { z_a: z1, z_b: z4, x_a: x1, x_b: x1, y_a: y1, y_b: y2 }, // left
        ]

        for (const edge of edges) {
          if ((edge.z_a <= level && edge.z_b >= level) || (edge.z_a >= level && edge.z_b <= level)) {
            if (Math.abs(edge.z_b - edge.z_a) > 0.01) {
              const t = (level - edge.z_a) / (edge.z_b - edge.z_a)
              const x = edge.x_a + t * (edge.x_b - edge.x_a)
              const y = edge.y_a + t * (edge.y_b - edge.y_a)

              if (
                !points.some((p) => Math.abs(p.x - x) < xs[1] - xs[0] * 0.1 && Math.abs(p.y - y) < ys[1] - ys[0] * 0.1)
              ) {
                points.push({ x, y, z: level })
              }
            }
          }
        }
      }
    }

    if (points.length >= 2) {
      contours.push(points)
    }
  }

  return contours
}

export function calculateDistance(x1: number, y1: number, x2: number, y2: number): number {
  return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
}

export function calculateAzimuth(x1: number, y1: number, x2: number, y2: number): number {
  const dx = x2 - x1
  const dy = y2 - y1
  let azimuth = Math.atan2(dx, dy) * (180 / Math.PI)
  if (azimuth < 0) azimuth += 360
  return azimuth
}

export function generateNetworkColors(edgeCount: number): string[] {
  const colors = [
    "#FF6B6B", // Red
    "#4ECDC4", // Teal
    "#FFE66D", // Yellow
    "#95E1D3", // Mint
    "#F38181", // Pink
    "#AA96DA", // Purple
    "#FCBAD3", // Light Pink
    "#A8DADC", // Light Blue
    "#FFB703", // Orange
    "#FB5607", // Deep Orange
    "#FFBE0B", // Gold
    "#8338EC", // Violet
    "#3A86FF", // Bright Blue
  ]

  const result: string[] = []
  for (let i = 0; i < edgeCount; i++) {
    result.push(colors[i % colors.length])
  }
  return result
}
